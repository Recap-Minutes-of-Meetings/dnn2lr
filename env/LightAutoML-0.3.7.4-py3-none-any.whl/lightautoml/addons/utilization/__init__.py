"""Tools to configure resources utilization."""
from .utilization import TimeUtilization


__all__ = ["TimeUtilization"]
